// OSIRIS Asset URLs - All verified CDN URLs from fresh uploads
// Last updated: 2026-03-27 - All 41 assets confirmed uploaded and tested

export const ASSET_URLS = {
  // ============ AUDIO ============
  audio: {
    intro_narration: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663180701130/YMNaFYPNBVUKvJbdDwnwD8/aud_intro_narration_e17de323.wav',
    intro_narration_v1: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663180701130/YMNaFYPNBVUKvJbdDwnwD8/aud_intro_narration_v1_2522b4cb.wav',
    yahya_monologue: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663180701130/YMNaFYPNBVUKvJbdDwnwD8/aud_yahya_monologue_4cc9724c.wav',
  },

  // ============ VIDEO ============
  video: {
    logo_reveal: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663180701130/YMNaFYPNBVUKvJbdDwnwD8/vid_logo_reveal_e046ce72.mp4',
    qabil_scene: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663180701130/YMNaFYPNBVUKvJbdDwnwD8/vid_qabil_scene_cf2f94d4.mp4',
  },

  // ============ BACKGROUNDS ============
  backgrounds: {
    berlin_1933: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663180701130/YMNaFYPNBVUKvJbdDwnwD8/bg_berlin_1933_a86c8d1e.png',
    cambodia_1975: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663180701130/YMNaFYPNBVUKvJbdDwnwD8/bg_cambodia_1975_c5282e82.png',
    corporate_lab: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663180701130/YMNaFYPNBVUKvJbdDwnwD8/bg_corporate_lab_2db6685d.png',
    granada_fall: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663180701130/YMNaFYPNBVUKvJbdDwnwD8/bg_granada_fall_582e149f.png',
    moscow_1937: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663180701130/YMNaFYPNBVUKvJbdDwnwD8/bg_moscow_1937_ee9ff2ff.png',
    nicaea_council: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663180701130/YMNaFYPNBVUKvJbdDwnwD8/bg_nicaea_council_f4ebd953.png',
    osiris_cosmic: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663180701130/YMNaFYPNBVUKvJbdDwnwD8/bg_osiris_cosmic_61c9c5b0.png',
    osiris_interface: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663180701130/YMNaFYPNBVUKvJbdDwnwD8/bg_osiris_interface_d275313a.png',
    pharaoh_temple: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663180701130/YMNaFYPNBVUKvJbdDwnwD8/bg_pharaoh_temple_98bcc51c.png',
    qabil_habil_aftermath: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663180701130/YMNaFYPNBVUKvJbdDwnwD8/bg_qabil_habil_aftermath_4d071a34.png',
    qabil_habil_altar: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663180701130/YMNaFYPNBVUKvJbdDwnwD8/bg_qabil_habil_altar_87782666.png',
    qabil_habil_rage: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663180701130/YMNaFYPNBVUKvJbdDwnwD8/bg_qabil_habil_rage_d1f7e300.png',
    white_space: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663180701130/YMNaFYPNBVUKvJbdDwnwD8/bg_white_space_1c056d5f.png',
    yahya_apartment: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663180701130/YMNaFYPNBVUKvJbdDwnwD8/bg_yahya_apartment_43c987a4.png',
  },

  // ============ CHARACTERS ============
  characters: {
    abu_abdullah: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663180701130/YMNaFYPNBVUKvJbdDwnwD8/char_abu_abdullah_42c31e2d.png',
    constantine: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663180701130/YMNaFYPNBVUKvJbdDwnwD8/char_constantine_b86e75a9.png',
    dictator: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663180701130/YMNaFYPNBVUKvJbdDwnwD8/char_dictator_a33f8325.png',
    first_engineer: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663180701130/YMNaFYPNBVUKvJbdDwnwD8/char_first_engineer_09fc3d1c.png',
    laila: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663180701130/YMNaFYPNBVUKvJbdDwnwD8/char_laila_2f851353.png',
    ramses: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663180701130/YMNaFYPNBVUKvJbdDwnwD8/char_ramses_acf59345.png',
    tarek: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663180701130/YMNaFYPNBVUKvJbdDwnwD8/char_tarek_40a39221.png',
    yahya_main: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663180701130/YMNaFYPNBVUKvJbdDwnwD8/char_yahya_main_6e00bea1.png',
  },

  // ============ DOCUMENTS ============
  documents: {
    encrypted_file: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663180701130/YMNaFYPNBVUKvJbdDwnwD8/doc_encrypted_file_c10f4f48.png',
    facebook_leak: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663180701130/YMNaFYPNBVUKvJbdDwnwD8/doc_facebook_leak_64b7fcbd.png',
    kgb_order: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663180701130/YMNaFYPNBVUKvJbdDwnwD8/doc_kgb_order_e0f72fd0.png',
    nicaea_scroll: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663180701130/YMNaFYPNBVUKvJbdDwnwD8/doc_nicaea_scroll_2f133ee9.png',
    ramses_carving: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663180701130/YMNaFYPNBVUKvJbdDwnwD8/doc_ramses_carving_eb77dd87.png',
  },

  // ============ UI ============
  ui: {
    logo_icon: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663180701130/YMNaFYPNBVUKvJbdDwnwD8/ui_logo_icon_c1fb9bc2.png',
    logo_primary: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663180701130/YMNaFYPNBVUKvJbdDwnwD8/ui_logo_primary_084de0f8.png',
    logo_dark: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663180701130/YMNaFYPNBVUKvJbdDwnwD8/ui_logo_dark_e0eb7967.png',
    bg_pattern: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663180701130/YMNaFYPNBVUKvJbdDwnwD8/ui_bg_pattern_739a77da.png',
  },
};
