/**
 * OSIRIS — المفسدون في الأرض
 * Main Player — Cinema-Mode Multimedia Interactive Digital Novel
 *
 * KEY DESIGN DECISIONS:
 * - User controls ALL progression (no auto-advance after dialogue finishes)
 * - Typewriter completes, then waits for user click/keypress to advance
 * - Narration audio: unique per scene, plays ONCE (no loop), stops on scene change
 * - Background music: separate ambient loop, volume-controlled independently
 * - Transitions: slow cinematic (1.8s fade in/out)
 * - Keyboard: Space/Enter = next, Backspace = prev dialogue, Escape = home
 */

import { useEffect, useRef, useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLocation } from 'wouter';
import { SCENES as ALL_SCENES, type Scene, type SceneChoice } from '@/lib/sceneSystem';
import { ASSET_URLS } from '@/lib/assetUrls';

interface MainPlayerProps {
  initialSceneId?: string;
}

// ─── Character Configuration ────────────────────────────────────────────────

interface CharacterConfig {
  name: string;
  arabicName: string;
  color: string;
  glowColor: string;
  imageUrl?: string;
  position: 'left' | 'right' | 'center';
}

const CHARACTER_MAP: Record<string, CharacterConfig> = {
  Narrator: {
    name: 'Narrator',
    arabicName: 'الراوي',
    color: '#c9a96e',
    glowColor: 'rgba(201,169,110,0.3)',
    position: 'center',
  },
  Iblis: {
    name: 'Iblis',
    arabicName: 'إبليس',
    color: '#ff4444',
    glowColor: 'rgba(255,68,68,0.35)',
    position: 'left',
  },
  Ramses: {
    name: 'Ramses',
    arabicName: 'رمسيس',
    color: '#d4af37',
    glowColor: 'rgba(212,175,55,0.3)',
    position: 'right',
    imageUrl: ASSET_URLS.characters.ramses,
  },
  Priest: {
    name: 'Mysterious Priest',
    arabicName: 'الكاهن الغامض',
    color: '#8b5cf6',
    glowColor: 'rgba(139,92,246,0.3)',
    position: 'left',
  },
  Moses: {
    name: 'Moses',
    arabicName: 'موسى',
    color: '#22c55e',
    glowColor: 'rgba(34,197,94,0.3)',
    position: 'right',
  },
  Constantine: {
    name: 'Constantine',
    arabicName: 'قسطنطين',
    color: '#3b82f6',
    glowColor: 'rgba(59,130,246,0.3)',
    position: 'right',
    imageUrl: ASSET_URLS.characters.constantine,
  },
  Arius: {
    name: 'Arius',
    arabicName: 'آريوس',
    color: '#a78bfa',
    glowColor: 'rgba(167,139,250,0.3)',
    position: 'left',
  },
  AbuAbdullah: {
    name: 'Abu Abdullah',
    arabicName: 'أبو عبد الله',
    color: '#f59e0b',
    glowColor: 'rgba(245,158,11,0.3)',
    position: 'right',
    imageUrl: ASSET_URLS.characters.abu_abdullah,
  },
  Qabil: {
    name: 'Qabil',
    arabicName: 'قابيل',
    color: '#ef4444',
    glowColor: 'rgba(239,68,68,0.35)',
    position: 'left',
  },
  Mother: {
    name: 'Mother',
    arabicName: 'الأم',
    color: '#a78bfa',
    glowColor: 'rgba(167,139,250,0.3)',
    position: 'left',
  },
  Bilal: {
    name: 'Bilal',
    arabicName: 'بلال',
    color: '#fbbf24',
    glowColor: 'rgba(251,191,36,0.3)',
    position: 'right',
    imageUrl: ASSET_URLS.characters.yahya_main,
  },
  Laila: {
    name: 'Laila',
    arabicName: 'ليلى',
    color: '#f472b6',
    glowColor: 'rgba(244,114,182,0.3)',
    position: 'right',
    imageUrl: ASSET_URLS.characters.laila,
  },
  Tarek: {
    name: 'Tarek',
    arabicName: 'طارق',
    color: '#60a5fa',
    glowColor: 'rgba(96,165,250,0.3)',
    position: 'left',
    imageUrl: ASSET_URLS.characters.tarek,
  },
  Yahya: {
    name: 'Yahya',
    arabicName: 'يحيى',
    color: '#34d399',
    glowColor: 'rgba(52,211,153,0.3)',
    position: 'left',
    imageUrl: ASSET_URLS.characters.yahya_main,
  },
  Hitler: {
    name: 'Hitler',
    arabicName: 'هتلر',
    color: '#dc2626',
    glowColor: 'rgba(220,38,38,0.35)',
    position: 'left',
  },
  Stalin: {
    name: 'Stalin',
    arabicName: 'ستالين',
    color: '#b91c1c',
    glowColor: 'rgba(185,28,28,0.35)',
    position: 'left',
  },
  PotPot: {
    name: 'Pol Pot',
    arabicName: 'بول بوت',
    color: '#991b1b',
    glowColor: 'rgba(153,27,27,0.35)',
    position: 'left',
  },
};

// ─── Emotional Tone Styles ───────────────────────────────────────────────────

const EMOTIONAL_OVERLAY: Record<string, string> = {
  dark: 'rgba(0,0,0,0.72)',
  hopeful: 'rgba(15,23,42,0.62)',
  intense: 'rgba(20,0,0,0.68)',
  contemplative: 'rgba(10,10,20,0.68)',
  tragic: 'rgba(5,5,5,0.75)',
};

const TONE_ACCENT: Record<string, string> = {
  dark: '#c9a96e',
  hopeful: '#93c5fd',
  intense: '#fca5a5',
  contemplative: '#a5b4fc',
  tragic: '#fcd34d',
};

// ─── Ambient Music by Part ───────────────────────────────────────────────────
// We only have narration audio files — NOT music files.
// Instead of looping narration as music (which causes the "الملف رقم واحد" repeat bug),
// we use Web Audio API to generate cinematic ambient drone tones per part.
// Each part gets a unique frequency/mood. No external files needed.

function createAmbientDrone(part: number, volume: number): (() => void) | null {
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    
    // Different base frequencies per part for unique moods
    const partFreqs: Record<number, number[]> = {
      0: [55, 82.5],      // Part 0: Deep cosmic — A1 + E2
      1: [49, 73.4],      // Part 1: Dark creation — G1 + D2
      2: [41.2, 61.7],    // Part 2: Pharaoh — E1 + B1
      3: [43.6, 65.4],    // Part 3: Nicaea — F1 + C2
      4: [46.2, 69.3],    // Part 4: Andalus — Bb1 + F2
      5: [36.7, 55],      // Part 5: 20th Century — D1 + A1 (darkest)
      6: [40, 60],        // Part 6: Digital — E1 + B1 (electronic feel)
      7: [55, 110],       // Part 7: Witnesses — A1 + A2 (hopeful octave)
    };
    
    const freqs = partFreqs[part] || [55, 82.5];
    const oscillators: OscillatorNode[] = [];
    const gainNode = ctx.createGain();
    gainNode.gain.setValueAtTime(0, ctx.currentTime);
    gainNode.gain.linearRampToValueAtTime(volume * 0.12, ctx.currentTime + 3);
    gainNode.connect(ctx.destination);
    
    freqs.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const oscGain = ctx.createGain();
      osc.type = i === 0 ? 'sine' : 'triangle';
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      // Slow vibrato for cinematic feel
      osc.frequency.setValueAtTime(freq * 1.001, ctx.currentTime + 4);
      osc.frequency.setValueAtTime(freq, ctx.currentTime + 8);
      oscGain.gain.setValueAtTime(i === 0 ? 0.7 : 0.3, ctx.currentTime);
      osc.connect(oscGain);
      oscGain.connect(gainNode);
      osc.start();
      oscillators.push(osc);
    });
    
    // Return cleanup function
    return () => {
      gainNode.gain.linearRampToValueAtTime(0, ctx.currentTime + 1.5);
      setTimeout(() => {
        oscillators.forEach(o => { try { o.stop(); } catch {} });
        ctx.close();
      }, 1600);
    };
  } catch {
    return null;
  }
}

// ─── Particles ───────────────────────────────────────────────────────────────

function Particles({ tone }: { tone: string }) {
  const color = TONE_ACCENT[tone] || '#c9a96e';
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden">
      {Array.from({ length: 10 }).map((_, i) => (
        <motion.div
          key={i}
          className="absolute rounded-full"
          style={{
            width: Math.random() * 2.5 + 1,
            height: Math.random() * 2.5 + 1,
            background: color,
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            opacity: 0,
          }}
          animate={{
            y: [0, -(Math.random() * 100 + 60)],
            opacity: [0, Math.random() * 0.4 + 0.1, 0],
          }}
          transition={{
            duration: Math.random() * 8 + 6,
            repeat: Infinity,
            delay: Math.random() * 10,
            ease: 'easeOut',
          }}
        />
      ))}
    </div>
  );
}

// ─── Volume Control UI ───────────────────────────────────────────────────────

function VolumeControl({
  narrationVol,
  musicVol,
  onNarrationChange,
  onMusicChange,
  isMuted,
  onToggleMute,
}: {
  narrationVol: number;
  musicVol: number;
  onNarrationChange: (v: number) => void;
  onMusicChange: (v: number) => void;
  isMuted: boolean;
  onToggleMute: () => void;
}) {
  const [open, setOpen] = useState(false);

  return (
    <div className="relative" onClick={(e) => e.stopPropagation()}>
      <button
        onClick={() => setOpen((p) => !p)}
        className="flex items-center gap-1 px-2 py-1 rounded-lg transition-all duration-200 hover:bg-white/10"
        style={{ color: 'rgba(201,169,110,0.7)' }}
        title="Audio Controls"
      >
        {isMuted ? (
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
            <line x1="23" y1="9" x2="17" y2="15" /><line x1="17" y1="9" x2="23" y2="15" />
          </svg>
        ) : (
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
            <path d="M19.07 4.93a10 10 0 0 1 0 14.14" /><path d="M15.54 8.46a5 5 0 0 1 0 7.07" />
          </svg>
        )}
        <span className="text-[9px] font-mono tracking-wider">AUDIO</span>
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -8, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            className="absolute top-full right-0 mt-2 p-4 rounded-xl z-50 min-w-[200px]"
            style={{
              background: 'rgba(0,0,0,0.92)',
              border: '1px solid rgba(201,169,110,0.2)',
              backdropFilter: 'blur(20px)',
            }}
          >
            <div className="mb-3">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[9px] font-mono tracking-wider text-amber-300/70">NARRATION</span>
                <span className="text-[9px] font-mono text-white/40">{Math.round(narrationVol * 100)}%</span>
              </div>
              <input
                type="range" min="0" max="1" step="0.05"
                value={narrationVol}
                onChange={(e) => onNarrationChange(parseFloat(e.target.value))}
                className="w-full h-1 rounded-full appearance-none cursor-pointer"
                style={{ accentColor: '#c9a96e' }}
              />
            </div>
            <div className="mb-3">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[9px] font-mono tracking-wider text-amber-300/70">AMBIENT MUSIC</span>
                <span className="text-[9px] font-mono text-white/40">{Math.round(musicVol * 100)}%</span>
              </div>
              <input
                type="range" min="0" max="1" step="0.05"
                value={musicVol}
                onChange={(e) => onMusicChange(parseFloat(e.target.value))}
                className="w-full h-1 rounded-full appearance-none cursor-pointer"
                style={{ accentColor: '#c9a96e' }}
              />
            </div>
            <button
              onClick={onToggleMute}
              className="w-full py-1.5 rounded-lg text-[9px] font-mono tracking-wider transition-all duration-200"
              style={{
                background: isMuted ? 'rgba(201,169,110,0.2)' : 'rgba(255,255,255,0.06)',
                color: isMuted ? '#c9a96e' : 'rgba(255,255,255,0.5)',
                border: '1px solid rgba(201,169,110,0.15)',
              }}
            >
              {isMuted ? '▶ UNMUTE ALL' : '⏸ MUTE ALL'}
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ─── Main Player ─────────────────────────────────────────────────────────────

export function MainPlayer({ initialSceneId = 'zero-1-1-summons' }: MainPlayerProps) {
  const [, setLocation] = useLocation();

  // Language state — 'en' or 'ar'
  const [lang, setLang] = useState<'en' | 'ar'>('ar');

  // Scene state
  const [currentSceneId, setCurrentSceneId] = useState(initialSceneId);
  const [dialogueIndex, setDialogueIndex] = useState(0);
  const [displayedText, setDisplayedText] = useState('');
  const [displayedArabic, setDisplayedArabic] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isDialogueComplete, setIsDialogueComplete] = useState(false);
  const [showChoices, setShowChoices] = useState(false);
  const [choiceProgress, setChoiceProgress] = useState(100);
  const [sceneTransitioning, setSceneTransitioning] = useState(false);
  const [bgLoaded, setBgLoaded] = useState(false);
  const [videoReady, setVideoReady] = useState(false);
  const [showCharacter, setShowCharacter] = useState(false);

  // Audio state
  const [audioEnabled, setAudioEnabled] = useState(false);
  const [showAudioPrompt, setShowAudioPrompt] = useState(true);
  const [narrationVol, setNarrationVol] = useState(0.75);
  const [musicVol, setMusicVol] = useState(0.18);
  const [isMuted, setIsMuted] = useState(false);
  const [narrationPlaying, setNarrationPlaying] = useState(false);

  // Refs
  const narrationRef = useRef<HTMLAudioElement | null>(null);
  const musicRef = useRef<HTMLAudioElement | null>(null);
  const bgVideoRef = useRef<HTMLVideoElement | null>(null);
  const typewriterRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const choiceIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const lastPartRef = useRef<number>(-1);

  const currentScene: Scene | undefined = ALL_SCENES[currentSceneId];
  const currentDialogue = currentScene?.dialogue?.[dialogueIndex];
  const currentCharConfig = currentDialogue?.character
    ? (CHARACTER_MAP[currentDialogue.character] || CHARACTER_MAP['Narrator'])
    : CHARACTER_MAP['Narrator'];

  const tone = currentScene?.emotionalTone || 'dark';
  const accentColor = TONE_ACCENT[tone] || '#c9a96e';
  const overlay = EMOTIONAL_OVERLAY[tone] || EMOTIONAL_OVERLAY.dark;

  // ── Audio: Enable on first interaction ──────────────────────────────────────
  const enableAudio = useCallback(() => {
    setAudioEnabled(true);
    setShowAudioPrompt(false);
  }, []);

  // ── Audio: Narration volume control ─────────────────────────────────────────
  const handleNarrationVol = useCallback((v: number) => {
    setNarrationVol(v);
    if (narrationRef.current && !isMuted) {
      narrationRef.current.volume = v;
    }
  }, [isMuted]);

  // ── Audio: Music volume control ──────────────────────────────────────────────
  const handleMusicVol = useCallback((v: number) => {
    setMusicVol(v);
    if (musicRef.current && !isMuted) {
      musicRef.current.volume = v;
    }
  }, [isMuted]);

  // ── Audio: Toggle mute ───────────────────────────────────────────────────────
  const handleToggleMute = useCallback(() => {
    const newMuted = !isMuted;
    setIsMuted(newMuted);
    if (narrationRef.current) narrationRef.current.volume = newMuted ? 0 : narrationVol;
    if (musicRef.current) musicRef.current.volume = newMuted ? 0 : musicVol;
  }, [isMuted, narrationVol, musicVol]);

  const typeText = useCallback((text: string, arabic: string, activeLang: 'en' | 'ar') => {
    if (typewriterRef.current) clearTimeout(typewriterRef.current);
    setDisplayedText('');
    setDisplayedArabic('');
    setIsTyping(true);
    setIsDialogueComplete(false);

    // Only type the active language text
    const activeText = activeLang === 'ar' ? arabic : text;
    let i = 0;
    const len = activeText.length;
    // Slower speed: 45-80ms per character for comfortable reading
    const speed = Math.max(45, Math.min(80, 5500 / Math.max(len, 1)));

    const tick = () => {
      i++;
      if (activeLang === 'ar') {
        setDisplayedArabic(arabic.slice(0, i));
      } else {
        setDisplayedText(text.slice(0, i));
      }
      if (i < len) {
        typewriterRef.current = setTimeout(tick, speed);
      } else {
        setIsTyping(false);
        setIsDialogueComplete(true); // Wait for user to click
      }
    };
    typewriterRef.current = setTimeout(tick, speed);
  }, []);

  // ── Advance to next dialogue line ──────────────────────────────────────────────────────────────────
  const advanceDialogue = useCallback(() => {
    if (!currentScene) return;
    const nextIdx = dialogueIndex + 1;
    if (nextIdx < currentScene.dialogue.length) {
      setDialogueIndex(nextIdx);
      setIsDialogueComplete(false);
      setShowCharacter(false);
      setTimeout(() => setShowCharacter(true), 250);
    } else {
      // End of dialogue — show choices or auto-go to next scene
      setShowChoices(true);
      if (!currentScene.choices || currentScene.choices.length === 0) {
        // No choices: wait for user to click to go to next scene
      }
    }
  }, [currentScene, dialogueIndex]);

  // ── Go to scene ──────────────────────────────────────────────────────────────
  const goToScene = useCallback((sceneId: string) => {
    if (!ALL_SCENES[sceneId]) return;
    setSceneTransitioning(true);
    if (choiceIntervalRef.current) clearInterval(choiceIntervalRef.current);
    if (typewriterRef.current) clearTimeout(typewriterRef.current);

    // Stop narration when changing scene
    if (narrationRef.current) {
      narrationRef.current.pause();
      narrationRef.current.src = '';
      narrationRef.current = null;
      setNarrationPlaying(false);
    }

    setTimeout(() => {
      setCurrentSceneId(sceneId);
      setDialogueIndex(0);
      setDisplayedText('');
      setDisplayedArabic('');
      setShowChoices(false);
      setChoiceProgress(100);
      setBgLoaded(false);
      setVideoReady(false);
      setShowCharacter(false);
      setIsDialogueComplete(false);
      setIsTyping(false);
      setSceneTransitioning(false);
      setTimeout(() => setShowCharacter(true), 600);
    }, 1800); // Slow cinematic transition: 1.8s
  }, []);

  // ── Handle choice selection ──────────────────────────────────────────────────
  const handleChoice = useCallback((choice: SceneChoice) => {
    if (choice.nextSceneId) {
      goToScene(choice.nextSceneId);
    }
  }, [goToScene]);

  // ── Handle screen click / Space / Enter ─────────────────────────────────────
  const handleAdvance = useCallback(() => {
    if (!audioEnabled) {
      enableAudio();
      return;
    }
    if (showChoices) return; // Don't advance when choices are shown

    if (isTyping) {
      // Skip typewriter — show full text immediately
      if (typewriterRef.current) clearTimeout(typewriterRef.current);
      setDisplayedText(currentDialogue?.text || '');
      setDisplayedArabic(currentDialogue?.arabicText || '');
      setIsTyping(false);
      setIsDialogueComplete(true);
      return;
    }

    if (isDialogueComplete) {
      advanceDialogue();
    }
  }, [audioEnabled, enableAudio, isTyping, isDialogueComplete, showChoices, currentDialogue, advanceDialogue]);

  // ── Handle "no choices" end-of-scene click ───────────────────────────────────
  const handleNoChoiceAdvance = useCallback(() => {
    if (!currentScene) return;
    const nextId = currentScene.defaultNextScene;
    if (nextId) {
      goToScene(nextId);
    } else {
      setLocation('/');
    }
  }, [currentScene, goToScene, setLocation]);

  // ── Keyboard navigation ──────────────────────────────────────────────────────
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === ' ' || e.key === 'Enter') {
        e.preventDefault();
        if (showChoices && (!currentScene?.choices || currentScene.choices.length === 0)) {
          handleNoChoiceAdvance();
        } else {
          handleAdvance();
        }
      }
      if (e.key === 'Escape') {
        setLocation('/');
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [handleAdvance, handleNoChoiceAdvance, showChoices, currentScene, setLocation]);

  // ── Start typewriter when dialogue changes ───────────────────────────────────
  useEffect(() => {
    if (!currentScene || !currentDialogue || showChoices) return;
    const text = currentDialogue.text || '';
    const arabic = currentDialogue.arabicText || '';
    const delay = currentDialogue.delay || 0;
    const start = () => typeText(text, arabic, lang);
    if (delay > 0) {
      const t = setTimeout(start, delay);
      return () => clearTimeout(t);
    } else {
      start();
    }
  }, [currentScene?.id, dialogueIndex, showChoices, lang]);;

  // ── Choice countdown timer ───────────────────────────────────────────────────
  useEffect(() => {
    if (!showChoices || !currentScene?.choices?.length) return;
    if (choiceIntervalRef.current) clearInterval(choiceIntervalRef.current);

    const timerMs = 30000; // Fixed 30-second timer for all choices
    const startTime = Date.now();

    choiceIntervalRef.current = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const remaining = Math.max(0, 100 - (elapsed / timerMs) * 100);
      setChoiceProgress(remaining);

      if (elapsed >= timerMs) {
        clearInterval(choiceIntervalRef.current!);
        const firstChoice = currentScene.choices![0];
        if (firstChoice?.nextSceneId) {
          goToScene(firstChoice.nextSceneId);
        }
      }
    }, 50);

    return () => {
      if (choiceIntervalRef.current) clearInterval(choiceIntervalRef.current);
    };
  }, [showChoices, currentScene?.id]);

  // ── Narration audio: unique per scene, plays ONCE, stops on scene change ─────
  useEffect(() => {
    if (!audioEnabled || !currentScene?.audioUrl) return;

    // Stop any previous narration
    if (narrationRef.current) {
      narrationRef.current.pause();
      narrationRef.current.src = '';
    }

    const audio = new Audio(currentScene.audioUrl);
    audio.loop = false; // NEVER loop narration
    audio.volume = isMuted ? 0 : narrationVol;
    narrationRef.current = audio;

    audio.play()
      .then(() => setNarrationPlaying(true))
      .catch(() => setNarrationPlaying(false));

    audio.onended = () => setNarrationPlaying(false);

    return () => {
      audio.pause();
      audio.src = '';
    };
  }, [currentSceneId, audioEnabled]);

  // ── Ambient drone: Web Audio API tone per PART (no external files needed) ───────
  const droneCleanupRef = useRef<(() => void) | null>(null);

  useEffect(() => {
    if (!audioEnabled || !currentScene) return;
    const part = currentScene.part;
    if (part === lastPartRef.current) return; // Same part — keep drone going
    lastPartRef.current = part;

    // Stop previous drone
    if (droneCleanupRef.current) {
      droneCleanupRef.current();
      droneCleanupRef.current = null;
    }

    if (isMuted) return;

    // Start new ambient drone for this part
    const cleanup = createAmbientDrone(part, musicVol);
    droneCleanupRef.current = cleanup;

    return () => {
      if (droneCleanupRef.current) {
        droneCleanupRef.current();
        droneCleanupRef.current = null;
      }
    };
  }, [currentScene?.part, audioEnabled, isMuted]);

  // ── Background video ─────────────────────────────────────────────────────────
  useEffect(() => {
    if (bgVideoRef.current && currentScene?.backgroundVideo) {
      bgVideoRef.current.src = currentScene.backgroundVideo;
      bgVideoRef.current.load();
      bgVideoRef.current.play().catch(() => {});
    }
  }, [currentSceneId]);

  // ── Cleanup on unmount ───────────────────────────────────────────────────────
  useEffect(() => {
    return () => {
      if (narrationRef.current) { narrationRef.current.pause(); narrationRef.current.src = ''; }
      if (musicRef.current) { musicRef.current.pause(); musicRef.current.src = ''; }
      if (typewriterRef.current) clearTimeout(typewriterRef.current);
      if (choiceIntervalRef.current) clearInterval(choiceIntervalRef.current);
    };
  }, []);

  // ─── Scene not found ──────────────────────────────────────────────────────────
  if (!currentScene) {
    return (
      <div className="w-screen h-screen bg-black flex items-center justify-center">
        <div className="text-center text-white">
          <p className="text-2xl mb-4 font-mono text-amber-400">Scene not found: {currentSceneId}</p>
          <button
            onClick={() => goToScene('zero-1-1-summons')}
            className="px-6 py-3 bg-amber-600 rounded-lg hover:bg-amber-500 transition-colors font-mono"
          >
            ← Return to Beginning
          </button>
        </div>
      </div>
    );
  }

  const partLabels: Record<number, { en: string; ar: string }> = {
    0: { en: 'Prologue', ar: 'المقدمة' },
    1: { en: 'Part I — The First Crime', ar: 'الجزء الأول — الجريمة الأولى' },
    2: { en: 'Part II — Pharaoh', ar: 'الجزء الثاني — فرعون' },
    3: { en: 'Part III — Nicaea', ar: 'الجزء الثالث — نيقية' },
    4: { en: 'Part IV — Andalus', ar: 'الجزء الرابع — الأندلس' },
    5: { en: 'Part V — 20th Century', ar: 'الجزء الخامس — القرن العشرون' },
    6: { en: 'Part VI — Digital Age', ar: 'الجزء السادس — الكبر الرقمي' },
    7: { en: 'Part VII — Witnesses', ar: 'الجزء السابع — شهود الدفاع' },
  };

  const partLabel = partLabels[currentScene.part] || { en: `Part ${currentScene.part}`, ar: `الجزء ${currentScene.part}` };
  const sceneKeys = Object.keys(ALL_SCENES);
  const currentIdx = sceneKeys.indexOf(currentSceneId);
  const timerSeconds = Math.ceil(choiceProgress / 100 * 30); // 30-second fixed timer

  // Is end of scene with no choices?
  const isEndOfScene = showChoices && (!currentScene.choices || currentScene.choices.length === 0);

  return (
    <div
      className="relative w-screen h-screen overflow-hidden bg-black select-none"
      style={{ fontFamily: "'Georgia', serif" }}
      onClick={handleAdvance}
    >
      {/* ── BACKGROUND VIDEO ── */}
      {currentScene.backgroundVideo && (
        <video
          ref={bgVideoRef}
          className="absolute inset-0 w-full h-full object-cover"
          autoPlay
          loop
          muted
          playsInline
          onCanPlay={() => setVideoReady(true)}
          style={{
            opacity: videoReady ? 1 : 0,
            transition: 'opacity 3s ease',
            filter: 'brightness(0.55) saturate(0.7)',
          }}
        />
      )}

      {/* ── BACKGROUND IMAGE ── */}
      {currentScene.backgroundImage && !currentScene.backgroundVideo && (
        <motion.img
          key={currentSceneId + '-bg'}
          src={currentScene.backgroundImage}
          alt=""
          className="absolute inset-0 w-full h-full object-cover"
          initial={{ opacity: 0, scale: 1.06 }}
          animate={{ opacity: bgLoaded ? 1 : 0, scale: bgLoaded ? 1.02 : 1.06 }}
          transition={{ duration: 3, ease: 'easeOut' }}
          onLoad={() => setBgLoaded(true)}
          onError={() => setBgLoaded(true)}
          style={{ filter: 'brightness(0.55) saturate(0.68)' }}
        />
      )}

      {/* ── CINEMATIC GRADIENT OVERLAY ── */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: `linear-gradient(
            to bottom,
            rgba(0,0,0,0.7) 0%,
            rgba(0,0,0,0.1) 25%,
            transparent 45%,
            transparent 52%,
            ${overlay} 100%
          )`,
        }}
      />

      {/* ── FILM GRAIN ── */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          opacity: 0.03,
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E")`,
          backgroundSize: '160px 160px',
        }}
      />

      {/* ── VIGNETTE ── */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse 80% 80% at 50% 50%, transparent 28%, rgba(0,0,0,0.65) 100%)',
        }}
      />

      {/* ── CINEMATIC LETTERBOX BARS ── */}
      <div className="absolute top-0 left-0 right-0 h-12 bg-black pointer-events-none z-10" />
      <div className="absolute bottom-0 left-0 right-0 h-12 bg-black pointer-events-none z-10" />

      {/* ── AMBIENT PARTICLES ── */}
      <Particles tone={tone} />

      {/* ── SCENE TRANSITION OVERLAY ── */}
      <AnimatePresence>
        {sceneTransitioning && (
          <motion.div
            className="absolute inset-0 bg-black z-50"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1.8 }}
          />
        )}
      </AnimatePresence>

      {/* ── AUDIO PERMISSION PROMPT ── */}
      <AnimatePresence>
        {showAudioPrompt && (
          <motion.div
            className="absolute inset-0 z-40 flex items-center justify-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.8 }}
            style={{ background: 'rgba(0,0,0,0.92)' }}
          >
            <motion.div
              initial={{ scale: 0.88, y: 24 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.88, y: 24 }}
              transition={{ duration: 0.6, ease: [0.25, 0.46, 0.45, 0.94] }}
              className="text-center px-10 py-12 rounded-2xl max-w-sm mx-4"
              style={{
                background: 'rgba(0,0,0,0.75)',
                border: '1px solid rgba(201,169,110,0.25)',
                backdropFilter: 'blur(24px)',
              }}
              onClick={(e) => e.stopPropagation()}
            >
              <img
                src={ASSET_URLS.ui.logo_icon}
                alt="OSIRIS"
                className="w-16 h-16 mx-auto mb-6 opacity-85"
                onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
              />
              <h2 className="text-3xl font-light text-amber-300 mb-1 tracking-[0.3em]">OSIRIS</h2>
              <p className="text-amber-200/55 text-sm font-arabic mb-1" dir="rtl">المفسدون في الأرض</p>
              <p className="text-white/35 text-[10px] mb-8 font-mono tracking-widest">A MULTIMEDIA INTERACTIVE DIGITAL NOVEL</p>
              <p className="text-white/60 text-sm mb-2 leading-relaxed">
                For the best experience, use headphones.
              </p>
              <p className="text-white/40 text-xs mb-8 leading-relaxed font-arabic" dir="rtl">
                للحصول على أفضل تجربة، استخدم سماعات الأذن
              </p>
              <button
                onClick={enableAudio}
                className="w-full py-4 rounded-xl font-semibold tracking-[0.2em] text-sm transition-all duration-300 hover:brightness-110 active:scale-95 text-black"
                style={{ background: 'linear-gradient(135deg, #c9a96e, #f0d080)' }}
              >
                ▶ BEGIN THE TRIAL
              </button>
              <p className="text-white/25 text-[10px] mt-3 font-arabic" dir="rtl">ابدأ المحاكمة</p>
              <p className="text-white/20 text-[9px] mt-4 font-mono">SPACE or CLICK to advance · ESC to exit</p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── TOP HUD ── */}
      <div className="absolute top-0 left-0 right-0 z-20 flex items-center justify-between px-6 h-12">
        {/* Back to Home */}
        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          onClick={(e) => { e.stopPropagation(); setLocation('/'); }}
          className="flex items-center gap-1.5 px-2 py-1 rounded-lg transition-all duration-200 hover:bg-white/10"
          style={{ color: 'rgba(201,169,110,0.55)' }}
        >
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <polyline points="15 18 9 12 15 6" />
          </svg>
          <span className="text-[9px] font-mono tracking-wider">HOME</span>
        </motion.button>

        {/* OSIRIS Logo Center */}
        <motion.div
          initial={{ opacity: 0, y: -6 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="flex items-center gap-2"
        >
          <img
            src={ASSET_URLS.ui.logo_icon}
            alt="OSIRIS"
            className="w-5 h-5 opacity-45"
            onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
          />
          <span className="text-amber-400/45 text-[9px] font-mono tracking-[0.5em]">OSIRIS</span>
        </motion.div>

        {/* Right controls: Language Toggle + Audio */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="flex items-center gap-3"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Language Toggle */}
          <div
            className="flex items-center rounded-lg overflow-hidden"
            style={{ border: '1px solid rgba(201,169,110,0.2)', background: 'rgba(0,0,0,0.5)' }}
          >
            <button
              onClick={() => setLang('ar')}
              className="px-2.5 py-1 text-[9px] font-mono tracking-wider transition-all duration-200"
              style={{
                background: lang === 'ar' ? 'rgba(201,169,110,0.25)' : 'transparent',
                color: lang === 'ar' ? '#c9a96e' : 'rgba(255,255,255,0.35)',
              }}
            >
              عر
            </button>
            <div style={{ width: '1px', height: '14px', background: 'rgba(201,169,110,0.15)' }} />
            <button
              onClick={() => setLang('en')}
              className="px-2.5 py-1 text-[9px] font-mono tracking-wider transition-all duration-200"
              style={{
                background: lang === 'en' ? 'rgba(201,169,110,0.25)' : 'transparent',
                color: lang === 'en' ? '#c9a96e' : 'rgba(255,255,255,0.35)',
              }}
            >
              EN
            </button>
          </div>
          <VolumeControl
            narrationVol={narrationVol}
            musicVol={musicVol}
            onNarrationChange={handleNarrationVol}
            onMusicChange={handleMusicVol}
            isMuted={isMuted}
            onToggleMute={handleToggleMute}
          />
        </motion.div>
      </div>

      {/* ── PROGRESS BAR ── */}
      <div className="absolute top-12 left-0 right-0 h-px z-20 bg-white/5">
        <motion.div
          className="h-full"
          style={{
            width: `${((currentIdx + 1) / sceneKeys.length) * 100}%`,
            background: `linear-gradient(to right, ${accentColor}40, ${accentColor}90)`,
          }}
          transition={{ duration: 1.2 }}
        />
      </div>

      {/* ── PART LABEL (bottom of top bar) ── */}
      <motion.div
        key={currentSceneId + '-part'}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 0.5 }}
        className="absolute z-20 flex flex-col items-center"
        style={{ top: '14px', left: '50%', transform: 'translateX(-50%)' }}
      >
        <span className="text-amber-400/50 text-[8px] font-mono tracking-[0.35em] uppercase">
          {lang === 'ar' ? partLabel.ar : partLabel.en}
        </span>
      </motion.div>

      {/* ── CHARACTER PORTRAIT ── */}
      <AnimatePresence mode="wait">
        {showCharacter && currentCharConfig.imageUrl && currentDialogue?.character !== 'Narrator' && (
          <motion.div
            key={(currentDialogue?.character || '') + '-portrait-' + dialogueIndex}
            className={`absolute bottom-32 ${currentCharConfig.position === 'left' ? 'left-6 md:left-14' : 'right-6 md:right-14'} z-10 pointer-events-none`}
            initial={{ opacity: 0, y: 40, scale: 0.88 }}
            animate={{ opacity: 0.92, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 25, scale: 0.92 }}
            transition={{ duration: 1.0, ease: [0.25, 0.46, 0.45, 0.94] }}
          >
            <div className="relative">
              <div
                className="absolute -inset-4 rounded-3xl blur-2xl opacity-25"
                style={{ background: currentCharConfig.glowColor }}
              />
              <img
                src={currentCharConfig.imageUrl}
                alt={currentCharConfig.name}
                className="relative w-28 h-40 md:w-36 md:h-52 object-cover rounded-2xl"
                style={{
                  boxShadow: `0 0 50px ${currentCharConfig.glowColor}, 0 20px 60px rgba(0,0,0,0.7)`,
                  border: `1px solid ${currentCharConfig.color}25`,
                  filter: 'brightness(0.85) contrast(1.05)',
                }}
                onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
              />
              <div
                className="absolute bottom-0 left-0 right-0 h-16 rounded-b-2xl"
                style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.9), transparent)' }}
              />
              <div
                className="absolute -bottom-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full text-[8px] font-mono tracking-wider whitespace-nowrap"
                style={{
                  background: 'rgba(0,0,0,0.85)',
                  border: `1px solid ${currentCharConfig.color}30`,
                  color: currentCharConfig.color,
                }}
              >
                {currentCharConfig.arabicName}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── MAIN DIALOGUE AREA ── */}
      <div className="absolute bottom-12 left-0 right-0 z-20 px-4 md:px-10 pb-4">
        <AnimatePresence mode="wait">
          {!showChoices && currentDialogue && (
            <motion.div
              key={currentSceneId + '-dlg-' + dialogueIndex}
              initial={{ opacity: 0, y: 28 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.8 }}
              className="max-w-4xl mx-auto"
            >
              {/* Character Name Badge */}
              {currentDialogue.character && (
                <motion.div
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5 }}
                  className="mb-3 flex items-center gap-3"
                >
                  <div
                    className="h-px flex-1 max-w-[50px]"
                    style={{ background: `linear-gradient(to right, transparent, ${currentCharConfig.color}70)` }}
                  />
                  <span
                    className="text-[10px] font-mono tracking-[0.22em] uppercase px-3 py-1 rounded-full border"
                    style={{
                      color: currentCharConfig.color,
                      borderColor: `${currentCharConfig.color}28`,
                      background: `${currentCharConfig.color}0d`,
                      textShadow: `0 0 16px ${currentCharConfig.glowColor}`,
                      fontFamily: lang === 'ar' ? "'Noto Naskh Arabic', serif" : 'inherit',
                    }}
                  >
                    {lang === 'ar' ? currentCharConfig.arabicName : currentCharConfig.name}
                  </span>
                  <div
                    className="h-px flex-1 max-w-[50px]"
                    style={{ background: `linear-gradient(to left, transparent, ${currentCharConfig.color}70)` }}
                  />
                </motion.div>
              )}

              {/* Dialogue Box */}
              <div
                className="relative rounded-2xl px-7 py-6 md:px-9 md:py-7"
                style={{
                  background: 'rgba(0,0,0,0.78)',
                  border: `1px solid ${currentCharConfig.color}12`,
                  boxShadow: `0 8px 60px rgba(0,0,0,0.75), 0 0 0 1px rgba(255,255,255,0.02), inset 0 1px 0 ${currentCharConfig.color}08`,
                  backdropFilter: 'blur(18px)',
                }}
              >
                {/* Active Language Text Only */}
                {lang === 'en' ? (
                  <p
                    className="text-white/93 text-xl md:text-2xl leading-relaxed font-light"
                    style={{
                      textShadow: '0 1px 8px rgba(0,0,0,0.98)',
                      letterSpacing: '0.012em',
                      lineHeight: '1.75',
                    }}
                  >
                    {displayedText}
                    {isTyping && (
                      <motion.span
                        className="inline-block w-0.5 h-6 ml-1 align-middle"
                        style={{ background: currentCharConfig.color }}
                        animate={{ opacity: [1, 0] }}
                        transition={{ duration: 0.55, repeat: Infinity }}
                      />
                    )}
                  </p>
                ) : (
                  <p
                    className="text-white/93 text-xl md:text-2xl leading-relaxed text-right"
                    dir="rtl"
                    style={{
                      textShadow: '0 1px 8px rgba(0,0,0,0.98)',
                      fontFamily: "'Noto Naskh Arabic', 'Amiri', serif",
                      letterSpacing: '0.04em',
                      lineHeight: '2',
                    }}
                  >
                    {displayedArabic}
                    {isTyping && (
                      <motion.span
                        className="inline-block w-0.5 h-6 mr-1 align-middle"
                        style={{ background: currentCharConfig.color }}
                        animate={{ opacity: [1, 0] }}
                        transition={{ duration: 0.55, repeat: Infinity }}
                      />
                    )}
                  </p>
                )}

                {/* Dialogue Progress Dots */}
                {currentScene.dialogue.length > 1 && (
                  <div className="flex items-center justify-center gap-2 mt-5">
                    {currentScene.dialogue.map((_, idx) => (
                      <motion.div
                        key={idx}
                        className="rounded-full"
                        animate={{
                          width: idx === dialogueIndex ? 24 : 5,
                          opacity: idx === dialogueIndex ? 1 : idx < dialogueIndex ? 0.45 : 0.15,
                        }}
                        transition={{ duration: 0.35 }}
                        style={{
                          height: 3,
                          background: idx === dialogueIndex
                            ? currentCharConfig.color
                            : idx < dialogueIndex
                              ? `${currentCharConfig.color}65`
                              : 'rgba(255,255,255,0.12)',
                        }}
                      />
                    ))}
                  </div>
                )}

                {/* CLICK TO CONTINUE — prominent when dialogue is complete */}
                <AnimatePresence>
                  {isDialogueComplete && !showChoices && (
                    <motion.div
                      initial={{ opacity: 0, y: 4 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      transition={{ duration: 0.4 }}
                      className="flex items-center justify-end gap-2 mt-4"
                    >
                      <motion.span
                        className="text-[11px] font-mono tracking-[0.2em] uppercase"
                        style={{
                          color: `${accentColor}90`,
                          fontFamily: lang === 'ar' ? "'Noto Naskh Arabic', serif" : 'inherit',
                        }}
                        animate={{ opacity: [0.55, 1, 0.55] }}
                        transition={{ duration: 2, repeat: Infinity }}
                      >
                        {lang === 'ar' ? 'انقر للمتابعة' : 'Click to continue'}
                      </motion.span>
                      <motion.span
                        style={{ color: `${accentColor}90`, fontSize: '14px' }}
                        animate={{ x: [0, 5, 0] }}
                        transition={{ duration: 1.5, repeat: Infinity }}
                      >
                        ›
                      </motion.span>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ── CHOICES ── */}
        <AnimatePresence>
          {showChoices && currentScene.choices && currentScene.choices.length > 0 && (
            <motion.div
              key="choices-panel"
              initial={{ opacity: 0, y: 36 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 28 }}
              transition={{ duration: 0.9 }}
              className="max-w-4xl mx-auto"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Timer Bar + Countdown */}
              <div className="mb-4 flex items-center gap-3">
                <div className="flex-1 h-0.5 bg-white/8 rounded-full overflow-hidden">
                  <motion.div
                    className="h-full rounded-full"
                    style={{
                      width: `${choiceProgress}%`,
                      background: choiceProgress > 55
                        ? `linear-gradient(to right, ${accentColor}80, ${accentColor})`
                        : choiceProgress > 22
                          ? 'linear-gradient(to right, #f97316, #fbbf24)'
                          : 'linear-gradient(to right, #ef4444, #f97316)',
                      transition: 'width 0.05s linear',
                    }}
                  />
                </div>
                {/* Countdown number */}
                <motion.span
                  className="text-[11px] font-mono tabular-nums flex-shrink-0 w-6 text-right"
                  style={{
                    color: choiceProgress > 55 ? `${accentColor}90`
                      : choiceProgress > 22 ? '#fbbf2490'
                      : '#ef444490',
                  }}
                  animate={{ scale: timerSeconds <= 5 ? [1, 1.2, 1] : 1 }}
                  transition={{ duration: 0.5, repeat: timerSeconds <= 5 ? Infinity : 0 }}
                >
                  {timerSeconds}
                </motion.span>
              </div>

              <div className="grid gap-3">
                {currentScene.choices.map((choice, idx) => (
                  <motion.button
                    key={choice.id}
                    initial={{ opacity: 0, x: idx % 2 === 0 ? -28 : 28 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.55, delay: idx * 0.1 }}
                    onClick={() => handleChoice(choice)}
                    className="group relative rounded-xl p-4 text-left transition-all duration-300 hover:scale-[1.01]"
                    style={{
                      background: 'rgba(0,0,0,0.72)',
                      border: `1px solid ${accentColor}20`,
                      boxShadow: '0 4px 30px rgba(0,0,0,0.5)',
                      backdropFilter: 'blur(14px)',
                    }}
                    onMouseEnter={(e) => {
                      const el = e.currentTarget as HTMLButtonElement;
                      el.style.borderColor = `${accentColor}55`;
                      el.style.background = `${accentColor}0a`;
                      el.style.boxShadow = `0 4px 40px ${accentColor}15`;
                    }}
                    onMouseLeave={(e) => {
                      const el = e.currentTarget as HTMLButtonElement;
                      el.style.borderColor = `${accentColor}20`;
                      el.style.background = 'rgba(0,0,0,0.72)';
                      el.style.boxShadow = '0 4px 30px rgba(0,0,0,0.5)';
                    }}
                  >
                    <div className="flex items-center gap-3">
                      <span
                        className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-mono flex-shrink-0"
                        style={{
                          background: `${accentColor}15`,
                          color: accentColor,
                          border: `1px solid ${accentColor}30`,
                        }}
                      >
                        {idx + 1}
                      </span>
                      <div className="flex-1 min-w-0">
                        {lang === 'en' ? (
                          <p className="text-white/88 text-sm font-light leading-snug">{choice.text}</p>
                        ) : (
                          <p className="text-white/93 text-sm leading-relaxed text-right" dir="rtl"
                            style={{ fontFamily: "'Noto Naskh Arabic', 'Amiri', serif", lineHeight: '1.9' }}
                          >{choice.arabicText || choice.text}</p>
                        )}
                      </div>
                      <span
                        className="text-base ml-1 flex-shrink-0 opacity-0 group-hover:opacity-70 transition-all duration-300"
                        style={{ color: accentColor }}
                      >
                        →
                      </span>
                    </div>
                  </motion.button>
                ))}
              </div>

              <p className="text-center text-white/30 text-[10px] mt-3 font-mono tracking-wider">
                {lang === 'ar'
                  ? `سيتابع تلقائياً خلال ${timerSeconds}ثانية`
                  : `Auto-continuing in ${timerSeconds}s`
                }
              </p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ── END OF SCENE (no choices) — click to continue ── */}
        <AnimatePresence>
          {isEndOfScene && (
            <motion.div
              key="end-of-scene"
              initial={{ opacity: 0, y: 28 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.8 }}
              className="max-w-4xl mx-auto text-center"
              onClick={(e) => { e.stopPropagation(); handleNoChoiceAdvance(); }}
            >
              <div
                className="inline-flex flex-col items-center gap-3 px-10 py-6 rounded-2xl cursor-pointer transition-all duration-300 hover:scale-[1.02]"
                style={{
                  background: 'rgba(0,0,0,0.75)',
                  border: `1px solid ${accentColor}22`,
                  backdropFilter: 'blur(16px)',
                }}
              >
                <motion.div
                  animate={{ opacity: [0.5, 1, 0.5] }}
                  transition={{ duration: 2.5, repeat: Infinity }}
                  className="flex items-center gap-3"
                >
                  {lang === 'ar' ? (
                    <span className="text-sm tracking-wider" dir="rtl"
                      style={{ color: `${accentColor}90`, fontFamily: "'Noto Naskh Arabic', serif" }}
                    >
                      انقر للمتابعة
                    </span>
                  ) : (
                    <span className="text-sm font-mono tracking-[0.25em] uppercase" style={{ color: `${accentColor}90` }}>
                      Continue
                    </span>
                  )}
                  <motion.span
                    style={{ color: `${accentColor}90`, fontSize: '18px' }}
                    animate={{ x: [0, 6, 0] }}
                    transition={{ duration: 1.8, repeat: Infinity }}
                  >
                    ›
                  </motion.span>
                </motion.div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* ── AUDIO STATUS INDICATOR ── */}
      {audioEnabled && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5 }}
          className="absolute bottom-14 left-5 z-30 flex items-center gap-2"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Narration indicator */}
          {narrationPlaying && (
            <div className="flex items-end gap-0.5" title="Narration playing">
              {[1, 2, 3, 2].map((h, i) => (
                <motion.div
                  key={i}
                  className="w-0.5 rounded-full"
                  style={{ background: `${accentColor}65` }}
                  animate={{ height: [h * 2, h * 4, h * 2] }}
                  transition={{
                    duration: 0.7,
                    repeat: Infinity,
                    delay: i * 0.12,
                    ease: 'easeInOut',
                  }}
                />
              ))}
            </div>
          )}
          {/* Music indicator */}
          {musicRef.current && !musicRef.current.paused && (
            <div className="flex items-end gap-0.5 opacity-40" title="Music playing">
              {[1, 2, 1].map((h, i) => (
                <motion.div
                  key={i}
                  className="w-0.5 rounded-full"
                  style={{ background: 'rgba(255,255,255,0.5)' }}
                  animate={{ height: [h * 2, h * 3, h * 2] }}
                  transition={{
                    duration: 1.2,
                    repeat: Infinity,
                    delay: i * 0.2,
                    ease: 'easeInOut',
                  }}
                />
              ))}
            </div>
          )}
        </motion.div>
      )}

      {/* ── KEYBOARD HINT ── */}
      {audioEnabled && !showAudioPrompt && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 3 }}
          className="absolute bottom-14 right-5 z-30 pointer-events-none"
        >
          <span className="text-[8px] font-mono tracking-wider text-white/18">
            SPACE · CLICK · ESC
          </span>
        </motion.div>
      )}
    </div>
  );
}

export default MainPlayer;
