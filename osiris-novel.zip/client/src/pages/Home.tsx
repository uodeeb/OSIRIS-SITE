/**
 * OSIRIS — المفسدون في الأرض
 * Home Page — Cinematic Landing Experience
 * Full-screen, immersive, with real CDN assets
 */

import { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLocation } from 'wouter';
import { ASSET_URLS } from '@/lib/assetUrls';

const PARTS = [
  {
    number: '0',
    en: 'The Cosmic Courtroom',
    ar: 'غرفة المحاكمة الكونية',
    description: 'The trial begins outside time and space',
    bg: ASSET_URLS.backgrounds.osiris_cosmic,
    color: '#c9a96e',
    sceneId: 'zero-1',
  },
  {
    number: 'I',
    en: 'The First Crime',
    ar: 'الجريمة الأولى',
    description: 'Pride — the sin before time',
    bg: ASSET_URLS.backgrounds.qabil_habil_altar,
    color: '#ef4444',
    sceneId: 'one-1',
  },
  {
    number: 'II',
    en: 'Pharaoh',
    ar: 'فرعون',
    description: 'Egypt, 13th Century BC',
    bg: ASSET_URLS.backgrounds.pharaoh_temple,
    color: '#d4af37',
    sceneId: 'two-1',
  },
  {
    number: 'III',
    en: 'Nicaea',
    ar: 'نيقية',
    description: 'When religion was stolen, 325 AD',
    bg: ASSET_URLS.backgrounds.nicaea_council,
    color: '#3b82f6',
    sceneId: 'three-1',
  },
  {
    number: 'IV',
    en: 'Andalus',
    ar: 'الأندلس',
    description: 'When we destroyed what we built',
    bg: ASSET_URLS.backgrounds.granada_fall,
    color: '#22c55e',
    sceneId: 'four-1',
  },
  {
    number: 'V',
    en: 'The 20th Century',
    ar: 'القرن العشرون',
    description: 'When pride became a system',
    bg: ASSET_URLS.backgrounds.berlin_1933,
    color: '#f97316',
    sceneId: 'five-1',
  },
  {
    number: 'VI',
    en: 'Digital Pride',
    ar: 'الكبر الرقمي',
    description: 'The algorithm of corruption',
    bg: ASSET_URLS.backgrounds.corporate_lab,
    color: '#8b5cf6',
    sceneId: 'six-1',
  },
  {
    number: 'VII',
    en: 'Witnesses for the Defense',
    ar: 'شهود الدفاع',
    description: 'The eternal answer',
    bg: ASSET_URLS.backgrounds.white_space,
    color: '#f0d080',
    sceneId: 'seven-1',
  },
];

function FloatingParticle({ delay, color }: { delay: number; color: string }) {
  const x = Math.random() * 100;
  return (
    <motion.div
      className="absolute rounded-full pointer-events-none"
      style={{
        left: `${x}%`,
        bottom: '-5%',
        width: Math.random() * 3 + 1,
        height: Math.random() * 3 + 1,
        background: color,
        opacity: 0,
      }}
      animate={{
        y: [0, -(Math.random() * 600 + 300)],
        opacity: [0, 0.6, 0],
        x: [0, (Math.random() - 0.5) * 80],
      }}
      transition={{
        duration: Math.random() * 8 + 7,
        repeat: Infinity,
        delay,
        ease: 'easeOut',
      }}
    />
  );
}

export default function Home() {
  const [, setLocation] = useLocation();
  const [hoveredPart, setHoveredPart] = useState<number | null>(null);
  const [bgLoaded, setBgLoaded] = useState(false);
  const [introPhase, setIntroPhase] = useState(0);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    // Intro animation sequence
    const t1 = setTimeout(() => setIntroPhase(1), 300);
    const t2 = setTimeout(() => setIntroPhase(2), 1200);
    const t3 = setTimeout(() => setIntroPhase(3), 2200);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); };
  }, []);

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.play().catch(() => {});
    }
  }, []);

  const handlePlay = () => {
    setLocation('/play');
  };

  const handlePartClick = (sceneId: string) => {
    setLocation(`/play?scene=${sceneId}`);
  };

  const activePart = hoveredPart !== null ? PARTS[hoveredPart] : null;

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-black" style={{ fontFamily: "'Georgia', serif" }}>

      {/* ── BACKGROUND VIDEO ── */}
      <video
        ref={videoRef}
        className="absolute inset-0 w-full h-full object-cover"
        src={ASSET_URLS.video.logo_reveal}
        autoPlay
        loop
        muted
        playsInline
        style={{ opacity: 0.3, filter: 'brightness(0.5) saturate(0.4)' }}
      />

      {/* ── BACKGROUND IMAGE (fallback + hovered part) ── */}
      <AnimatePresence>
        {activePart && (
          <motion.img
            key={activePart.sceneId + '-bg'}
            src={activePart.bg}
            alt=""
            className="absolute inset-0 w-full h-full object-cover"
            initial={{ opacity: 0, scale: 1.08 }}
            animate={{ opacity: 0.25, scale: 1.03 }}
            exit={{ opacity: 0, scale: 1.06 }}
            transition={{ duration: 0.8 }}
            style={{ filter: 'brightness(0.5) saturate(0.5)' }}
          />
        )}
      </AnimatePresence>

      {/* ── MAIN GRADIENT OVERLAY ── */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: `
            radial-gradient(ellipse 80% 60% at 50% 40%, rgba(201,169,110,0.04) 0%, transparent 60%),
            linear-gradient(to bottom, rgba(0,0,0,0.85) 0%, rgba(0,0,0,0.3) 40%, rgba(0,0,0,0.7) 100%)
          `,
        }}
      />

      {/* ── FILM GRAIN ── */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          opacity: 0.04,
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E")`,
          backgroundSize: '150px 150px',
        }}
      />

      {/* ── VIGNETTE ── */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{ background: 'radial-gradient(ellipse 80% 80% at 50% 50%, transparent 25%, rgba(0,0,0,0.75) 100%)' }}
      />

      {/* ── FLOATING PARTICLES ── */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {Array.from({ length: 20 }).map((_, i) => (
          <FloatingParticle key={i} delay={i * 0.7} color="#c9a96e" />
        ))}
      </div>

      {/* ── CINEMATIC LETTERBOX ── */}
      <div className="absolute top-0 left-0 right-0 h-12 bg-black pointer-events-none z-10" />
      <div className="absolute bottom-0 left-0 right-0 h-12 bg-black pointer-events-none z-10" />

      {/* ── MAIN CONTENT ── */}
      <div className="relative z-20 w-full h-full flex flex-col items-center justify-between py-16 px-6">

        {/* ── HEADER / LOGO ── */}
        <motion.div
          className="flex flex-col items-center gap-3"
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: introPhase >= 1 ? 1 : 0, y: introPhase >= 1 ? 0 : -30 }}
          transition={{ duration: 1.2, ease: [0.25, 0.46, 0.45, 0.94] }}
        >
          {/* Logo */}
          <div className="relative">
            <motion.div
              className="absolute -inset-6 rounded-full blur-3xl opacity-20"
              style={{ background: 'radial-gradient(circle, #c9a96e, transparent)' }}
              animate={{ scale: [1, 1.2, 1], opacity: [0.15, 0.3, 0.15] }}
              transition={{ duration: 4, repeat: Infinity }}
            />
            <img
              src={ASSET_URLS.ui.logo_icon}
              alt="OSIRIS"
              className="relative w-14 h-14 opacity-80"
              onLoad={() => setBgLoaded(true)}
              onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
            />
          </div>

          {/* Title */}
          <div className="text-center">
            <h1
              className="text-5xl md:text-7xl font-light tracking-[0.35em] text-amber-300"
              style={{ textShadow: '0 0 60px rgba(201,169,110,0.5), 0 2px 4px rgba(0,0,0,0.9)' }}
            >
              OSIRIS
            </h1>
            <p
              className="text-2xl md:text-3xl font-arabic text-amber-200/70 mt-1"
              dir="rtl"
              style={{ textShadow: '0 2px 8px rgba(0,0,0,0.9)' }}
            >
              المفسدون في الأرض
            </p>
          </div>

          {/* Subtitle */}
          <motion.div
            className="flex flex-col items-center gap-1"
            initial={{ opacity: 0 }}
            animate={{ opacity: introPhase >= 2 ? 1 : 0 }}
            transition={{ duration: 1 }}
          >
            <div className="flex items-center gap-3">
              <div className="h-px w-16 bg-gradient-to-r from-transparent to-amber-400/40" />
              <span className="text-amber-400/55 text-[9px] font-mono tracking-[0.4em] uppercase">
                Six Thousand Years · ستة آلاف سنة
              </span>
              <div className="h-px w-16 bg-gradient-to-l from-transparent to-amber-400/40" />
            </div>
            <p className="text-white/35 text-[10px] font-mono tracking-wider">
              A Multimedia Interactive Digital Novel
            </p>
          </motion.div>
        </motion.div>

        {/* ── PARTS GRID ── */}
        <motion.div
          className="w-full max-w-5xl"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: introPhase >= 3 ? 1 : 0, y: introPhase >= 3 ? 0 : 30 }}
          transition={{ duration: 1, delay: 0.2 }}
        >
          <div className="grid grid-cols-4 md:grid-cols-8 gap-2 mb-6">
            {PARTS.map((part, idx) => (
              <motion.button
                key={part.number}
                className="relative group rounded-xl overflow-hidden cursor-pointer"
                style={{ aspectRatio: '1/1.4' }}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.3 + idx * 0.06 }}
                onClick={() => handlePartClick(part.sceneId)}
                onMouseEnter={() => setHoveredPart(idx)}
                onMouseLeave={() => setHoveredPart(null)}
                whileHover={{ scale: 1.05, y: -4 }}
                whileTap={{ scale: 0.97 }}
              >
                {/* Part background */}
                <img
                  src={part.bg}
                  alt={part.en}
                  className="absolute inset-0 w-full h-full object-cover transition-all duration-700 group-hover:scale-110"
                  style={{ filter: 'brightness(0.45) saturate(0.6)' }}
                  onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
                />
                <div
                  className="absolute inset-0 transition-all duration-500 group-hover:opacity-70"
                  style={{ background: 'rgba(0,0,0,0.55)' }}
                />
                {/* Bottom gradient */}
                <div
                  className="absolute bottom-0 left-0 right-0 h-3/4"
                  style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.9), transparent)' }}
                />
                {/* Color accent line */}
                <div
                  className="absolute top-0 left-0 right-0 h-0.5 transition-all duration-300 group-hover:h-1"
                  style={{ background: part.color }}
                />
                {/* Part number */}
                <div className="absolute inset-0 flex flex-col items-center justify-end p-2">
                  <span
                    className="text-[10px] font-mono font-bold leading-none mb-1"
                    style={{ color: part.color, textShadow: `0 0 15px ${part.color}80` }}
                  >
                    {part.number}
                  </span>
                  <p
                    className="text-white/70 text-[8px] font-arabic text-center leading-tight"
                    dir="rtl"
                    style={{ fontSize: '7px' }}
                  >
                    {part.ar}
                  </p>
                </div>
                {/* Hover glow */}
                <div
                  className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
                  style={{
                    background: `radial-gradient(ellipse at center, ${part.color}15 0%, transparent 70%)`,
                    boxShadow: `inset 0 0 30px ${part.color}20`,
                  }}
                />
              </motion.button>
            ))}
          </div>

          {/* Hovered Part Info */}
          <AnimatePresence mode="wait">
            {activePart && (
              <motion.div
                key={activePart.sceneId}
                className="text-center mb-4"
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.3 }}
              >
                <p className="text-[11px] font-mono tracking-wider" style={{ color: activePart.color }}>
                  Part {activePart.number} — {activePart.en}
                </p>
                <p className="text-white/40 text-[10px] mt-0.5">{activePart.description}</p>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>

        {/* ── CTA BUTTON ── */}
        <motion.div
          className="flex flex-col items-center gap-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: introPhase >= 3 ? 1 : 0, y: introPhase >= 3 ? 0 : 20 }}
          transition={{ duration: 1, delay: 0.5 }}
        >
          <motion.button
            onClick={handlePlay}
            className="relative group px-14 py-4 rounded-2xl overflow-hidden font-mono tracking-widest text-sm text-black font-semibold"
            style={{ background: 'linear-gradient(135deg, #c9a96e, #f0d080, #c9a96e)' }}
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.97 }}
          >
            {/* Shimmer */}
            <motion.div
              className="absolute inset-0 opacity-0 group-hover:opacity-100"
              style={{
                background: 'linear-gradient(105deg, transparent 30%, rgba(255,255,255,0.35) 50%, transparent 70%)',
              }}
              animate={{ x: ['-100%', '200%'] }}
              transition={{ duration: 1.8, repeat: Infinity, repeatDelay: 1 }}
            />
            <span className="relative">▶ BEGIN THE TRIAL</span>
          </motion.button>

          <div className="flex items-center gap-4 text-white/25 text-[9px] font-mono tracking-wider">
            <span>🎬 Cinema Mode</span>
            <span>·</span>
            <span>🎵 Immersive Audio</span>
            <span>·</span>
            <span>🌐 Arabic & English</span>
          </div>

          {/* Stats */}
          <div className="flex items-center gap-8">
            {[
              { n: '8', label: 'Parts', ar: 'أجزاء' },
              { n: '6000', label: 'Years', ar: 'سنة' },
              { n: '41', label: 'Assets', ar: 'مقطع' },
            ].map((stat) => (
              <div key={stat.n} className="text-center">
                <p className="text-amber-400/80 text-lg font-mono font-bold leading-none">{stat.n}</p>
                <p className="text-white/30 text-[8px] font-mono tracking-wider mt-0.5">{stat.label}</p>
                <p className="text-amber-300/20 text-[7px] font-arabic" dir="rtl">{stat.ar}</p>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
